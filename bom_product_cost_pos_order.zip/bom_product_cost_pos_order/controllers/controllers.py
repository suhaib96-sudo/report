# -*- coding: utf-8 -*-
from odoo import http

# class BomProductCostPosOrder(http.Controller):
#     @http.route('/bom_product_cost_pos_order/bom_product_cost_pos_order/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/bom_product_cost_pos_order/bom_product_cost_pos_order/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('bom_product_cost_pos_order.listing', {
#             'root': '/bom_product_cost_pos_order/bom_product_cost_pos_order',
#             'objects': http.request.env['bom_product_cost_pos_order.bom_product_cost_pos_order'].search([]),
#         })

#     @http.route('/bom_product_cost_pos_order/bom_product_cost_pos_order/objects/<model("bom_product_cost_pos_order.bom_product_cost_pos_order"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('bom_product_cost_pos_order.object', {
#             'object': obj
#         })