# -*- coding: utf-8 -*-

from odoo import models, fields, api
import pytz
from odoo.tools import float_round
from operator import itemgetter

class PosDetails(models.TransientModel):
    _inherit = 'pos.details.wizard'

    #
    # @api.multi
    # def generate_report(self):
    #     # data = {'include_flavour':self.include_flavour}
    #     res = super(PosDetails,self).generate_report()
    #     print'ressssssssss',res
    #
    #     return res

class ReportSaleDetails(models.AbstractModel):

    _inherit = 'report.point_of_sale.report_saledetails'
    # @api.multi
    # def render_html(self, docids, data=None):
    #     data = dict(data or {})
    #     configs = self.env['pos.config'].browse(data['config_ids'])
    #     data['configs']=configs
    #     data['include_cost'] = self.env
    #     data.update(self.get_sale_details(data['date_start'], data['date_stop'], configs,data['include_flavour']))
    #
    #     return self.env['report'].render('point_of_sale.report_saledetails', data)


    @api.model
    def get_sale_details(self, date_start=False, date_stop=False, configs=False,include_flavour=False):
        """ Serialise the orders of the day information

        params: date_start, date_stop string representing the datetime of order
        """
        two_decimal_place = self.env['decimal.precision'].precision_get('Two Decimal Place')
        if not configs:
            configs = self.env['pos.config'].search([])

        user_tz = pytz.timezone(self.env.context.get('tz') or self.env.user.tz or 'UTC')
        today = user_tz.localize(fields.Datetime.from_string(fields.Date.context_today(self)))
        today = today.astimezone(pytz.timezone('UTC'))
        if date_start:
            date_start = fields.Datetime.from_string(date_start)
        else:
            # start by default today 00:00:00
            date_start = today

        if date_stop:
            # set time to 23:59:59
            date_stop = fields.Datetime.from_string(date_stop)
        else:
            # stop by default today 23:59:59
            date_stop = today + timedelta(days=1, seconds=-1)

        # avoid a date_stop smaller than date_start
        date_stop = max(date_stop, date_start)

        date_start = fields.Datetime.to_string(date_start)
        date_stop = fields.Datetime.to_string(date_stop)

        orders = self.env['pos.order'].search([
            ('date_order', '>=', date_start),
            ('date_order', '<=', date_stop),
            ('state', 'in', ['paid','invoiced','done']),
            ('config_id', 'in', configs.ids)])

        user_currency = self.env.user.company_id.currency_id
        # include_flavour = False
        total = 0.0
        products_sold = {}
        taxes = {}
        for order in orders:
            if user_currency != order.pricelist_id.currency_id:
                total += order.pricelist_id.currency_id.compute(order.amount_total, user_currency)
            else:
                total += order.amount_total
            currency = order.session_id.currency_id

            for line in order.lines:
                price_subtotal = 0.0
                if not include_flavour and line.product_id.categ_id.name == 'Gelato Flavours':
                    continue;
                key = (line.product_id, line.price_unit, line.discount,line.tax_ids_after_fiscal_position)
                products_sold.setdefault(key, 0.0)
                products_sold[key] += line.qty
                price_subtotal = price_subtotal + line.price_subtotal
                # products_sold
                if line.tax_ids_after_fiscal_position:
                    line_taxes = line.tax_ids_after_fiscal_position.compute_all(line.price_unit * (1-(line.discount or 0.0)/100.0), currency, line.qty, product=line.product_id, partner=line.order_id.partner_id or False)
                    for tax in line_taxes['taxes']:
                        taxes.setdefault(tax['id'], {'name': tax['name'], 'total':0.0})
                        taxes[tax['id']]['total'] += tax['amount']
        st_line_ids = self.env["account.bank.statement.line"].search([('pos_statement_id', 'in', orders.ids)]).ids
        if st_line_ids:
            self.env.cr.execute("""
                SELECT aj.name, sum(amount) total
                FROM account_bank_statement_line AS absl,
                     account_bank_statement AS abs,
                     account_journal AS aj
                WHERE absl.statement_id = abs.id
                    AND abs.journal_id = aj.id
                    AND absl.id IN %s
                GROUP BY aj.name
            """, (tuple(st_line_ids),))
            payments = self.env.cr.dictfetchall()
        else:
            payments = []
        products_data = sorted([{
                'product_id': product.id,
                # 'line_amount':user_currency.round(self.get_lineamount(qty,self.get_price(price_unit,discount))),
                # 'line_percentage':user_currency.round(self._get_line_percentage(total,self.get_lineamount(qty,self.get_price(price_unit,discount)))),
                'product_name': product.name,
                'code': product.default_code,
                'quantity': float_round(qty,two_decimal_place),
                'price': user_currency.round(float_round(price_unit,two_decimal_place)),
                'price_unit': user_currency.round(self.get_price(price_unit,discount)),
                # 'price_unit': price_unit,
                'discount': discount,
                # 'cost':product.standard_price,
                'cost':self.get_cost(product),
                'discount_amount':user_currency.round(self._get_discount_amount(price_unit,discount)),
                'uom': product.uom_id.name,
                'tax_ids':tax_ids,
                'tax_amount':user_currency.round(self._tax_amount(tax_ids,price_unit,qty,discount)),
            } for (product, price_unit, discount,tax_ids), qty in products_sold.items()], key=lambda l: l['product_name'])

        # print'products_data',
        for p_data in products_data:
            qty = p_data.get('quantity')
            price_unit = p_data.get('price_unit')
            tax_amount = p_data.get('tax_amount')
            line_amount_incl = user_currency.round(self._get_order_amount_incl(qty,price_unit,tax_amount))
            line_amount = user_currency.round(self._get_line_amount(qty,price_unit))
            line_percentage = user_currency.round(self._get_line_percentage(total,line_amount_incl))
            p_data['line_amount_incl']=line_amount_incl
            p_data['line_amount']=line_amount
            p_data['line_percentage']=line_percentage
        products_data=sorted(products_data, key=itemgetter('line_percentage'),reverse=True)
        return {
            'total_paid': user_currency.round(total),
            'payments': payments,
            'company_name': self.env.user.company_id.name,
            'taxes': taxes.values(),
            'products':products_data
            }

    def get_cost(self,product):
        cost = 0.0
        if product.bom_ids:
            # print'ifffffffffffffffff',product.bom_ids.cost_per_unit
            cost = product.bom_ids.cost_per_unit
            return cost
        else:
            return product.standard_price
